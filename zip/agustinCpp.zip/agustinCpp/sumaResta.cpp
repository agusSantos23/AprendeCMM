#include <iostream>
using namespace std;

int main(){

    int a, b;

    cout << "Ingrese un numero: ";
    cin >> a;

    cout << "Ingrese un segundo numero: ";
    cin >> b;

    cout << "Suma:"<< endl << a + b << endl;

    cout << "Resta:"<< endl << a - b << endl;



    return 0;

}